    // Programa para teste do avr-gcc  
      
#include <inttypes.h>  
#include <avr/io.h>  
#include <util/delay.h>
#include "digital.h"
   
      
    // Programa Principal  
int main (void)  
{  
	uart_init();
	_delay_ms(5000);
	printf("AT+NAMEUFSC\r\n");
    printf("AT+PIN1234\r\n");
	

	while (1)
	{
		printf("Teste\n");
	}

        return 0;
}  
      
    
