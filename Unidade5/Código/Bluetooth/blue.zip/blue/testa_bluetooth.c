    // Programa para teste do avr-gcc  
      
#include <inttypes.h>  
#include <avr/io.h>  
#include <util/delay.h>
#include <stdio.h>
#include "uart.h"



   
      
    // Programa Principal  
int main (void)  
{  
	uart_init();
	_delay_ms(5000);
   _delay_ms(3000); 
	printf("AT\r\n");
	_delay_ms(3000);
    printf("AT+RESET\r\n");
	_delay_ms(3000);
	printf("AT+NAMESENSORES_BEBE\r\n");
	_delay_ms(3000);
 printf("AT+RESET\r\n");
	_delay_ms(3000);

	while (1)
	{
		printf("Teste\n");
		_delay_ms(500);
	}

        return 0;
}  
      
    
