#ifndef PROXY_H
#define PROXY_H
#include <Windows.h>

void InitializeProxy(HMODULE hOriginal);
#endif//PROXY_H
