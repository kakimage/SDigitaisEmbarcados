#ifndef BASICS_H
#define BASICS_H
#include <Windows.h>
#include "spifns.h"

#endif//BASICS_H
